﻿using static EvaluationProjectWPF.UniversityManager;

namespace EvaluationProjectWPF
{
    internal class Courses
    {
        public bool isStudent;

        public bool isTeacher;
        public string? CourseTitle { get; set; }

        public int OralMark { get; set; }

        public int WritingMark { get; set; }

    }
}
